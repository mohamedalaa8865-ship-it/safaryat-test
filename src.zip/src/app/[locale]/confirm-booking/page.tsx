// 'use client';

// import { useEffect, useState, Suspense } from 'react';
// import { useSearchParams, useRouter } from 'next/navigation';
// import { useFirestore, useUser } from '@/firebase';
// import { doc, getDoc, collection, serverTimestamp, writeBatch, arrayUnion, increment, setDoc, deleteField } from 'firebase/firestore';
// import { Loader2, CheckCircle2, XCircle } from 'lucide-react';
// import { Button } from '@/components/ui/button';
// import { BookingDialog } from '@/components/booking-dialog';
// import type { Trip, PassengerDetails } from '@/lib/data';
// import { useLocale, useTranslations } from 'next-intl';
// import { sendPush } from "@/lib/send-push";

// /**
//  * @file src/app/[locale]/confirm-booking/page.tsx
//  * @description THE STERILIZED BOOKING CONFIRMATION (REINFORCED - SC-806 V6.1)
//  * [FIX]: تم الفصل الذكي بين حجز "الرحلات المجدولة" و "الطلبات الخاصة" لمنع اختفاء الرحلات
//  */

// type Status = 'loading' | 'ready' | 'confirming' | 'success' | 'error' | 'expired';

// export default function ConfirmBookingPage() {
//   return (
//     <Suspense fallback={<div className="flex items-center justify-center min-h-screen"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>}>
//       <ConfirmBookingContent />
//     </Suspense>
//   );
// }

// function ConfirmBookingContent() {
//   const searchParams = useSearchParams();
//   const router = useRouter();
//   const firestore = useFirestore();
//   const { user } = useUser();
//   const locale = useLocale();
//   const tError = useTranslations('errorDictionary');
//   const t = useTranslations('ConfirmBooking');
//   const token = searchParams.get('token');

//   const [status, setStatus] = useState<Status>('loading');
//   const [tokenData, setTokenData] = useState<any>(null);
//   const [trip, setTrip] = useState<Trip | null>(null);
//   const [isDialogOpen, setIsDialogOpen] = useState(false);
//   const [errorCode, setErrorCode] = useState('DEFAULT');

//   useEffect(() => {
//     if (!token || !firestore) return;

//     const verifyToken = async () => {
//       try {
//         const tokenRef = doc(firestore, 'booking_tokens', token);
//         const tokenSnap = await getDoc(tokenRef);

//         if (!tokenSnap.exists()) {
//           setStatus('error');
//           setErrorCode('TOKEN_INVALID');
//           return;
//         }

//         const data = tokenSnap.data();

//         if (data.status === 'used') {
//           setStatus('error');
//           setErrorCode('TOKEN_USED');
//           return;
//         }

//         const expiresAt = data.expiresAt?.toDate?.() || new Date(data.expiresAt);
//         if (new Date() > expiresAt) {
//           setStatus('error');
//           setErrorCode('TOKEN_EXPIRED');
//           return;
//         }

//         const tripRef = doc(firestore, 'trips', data.tripId);
//         const tripSnap = await getDoc(tripRef);

//         if (!tripSnap.exists()) {
//           setStatus('error');
//           setErrorCode('TRIP_NOT_FOUND');
//           return;
//         }

//         setTokenData(data);
//         setTrip({ id: tripSnap.id, ...tripSnap.data() } as Trip);
//         setStatus('ready');
//         setIsDialogOpen(true);
//       } catch (err) {
//         console.error('[VerifyToken Error]', err);
//         setStatus('error');
//         setErrorCode('VERIFICATION_FAILED');
//       }
//     };

//     verifyToken();
//   }, [token, firestore]);

//   const handleConfirmBooking = async (passengers: PassengerDetails[]) => {
//     if (!firestore || !tokenData || !trip || !token) throw new Error('MISSING_DATA');
//     if (!user?.uid) throw new Error('AUTH_REQUIRED');

//     setStatus('confirming');

//     try {
//       const batch = writeBatch(firestore);
//       const tokenRef = doc(firestore, 'booking_tokens', token);

//       if (tokenData.bookingId) {
//         // ══════════════════════════════════════════════════════════════════
//         // المسار الجاي من وكيل
//         // ══════════════════════════════════════════════════════════════════
//         const existingBookingRef = doc(firestore, 'bookings', tokenData.bookingId);

//         batch.update(existingBookingRef, {
//           userId: user.uid,
//           passengersDetails: passengers,
//           seats: passengers.length,
//           depositPaid: true,
//           depositPercentage: trip.depositPercentage ?? 0,
//           verifiedEmail: tokenData.email || null,
//           status: 'Pending-Carrier-Confirmation',
//           updatedAt: serverTimestamp(),
//         });

//         batch.update(tokenRef, { status: 'used', usedAt: serverTimestamp() });

//         if (tokenData.carrierTripId) {
//           const carrierTripRef = doc(firestore, 'trips', tokenData.carrierTripId);
//           batch.update(carrierTripRef, {
//             bookingIds: arrayUnion(tokenData.bookingId),
//             updatedAt: serverTimestamp(),
//           });
//         }

//         const userRef = doc(firestore, 'users', user.uid);
//         batch.set(userRef, {
//           activeBookingId: tokenData.bookingId,
//           // activeIntentId: null,
//           activeIntentId: deleteField(),

//           updatedAt: serverTimestamp(),
//         }, { merge: true });

//         if (trip.carrierId) {
//           const notifRef = doc(collection(doc(firestore, 'users', trip.carrierId), 'notifications'));
//           batch.set(notifRef, {
//             userId: trip.carrierId,
//             title: 'مسافر أكمّل بيانات الحجز ✅',
//             message: `المسافر "${passengers[0]?.name || ''}" أكمل بياناته ودفع العربون — ${passengers.length} مقعد`,
//             type: 'passenger_deposit_paid',
//             bookingId: tokenData.bookingId,
//             isRead: false,
//             link: `/${locale}/carrier/bookings`,
//             createdAt: serverTimestamp(),
//           });
//         }

//         await batch.commit();

//         if (trip.carrierId) {
//           await sendPush({
//             userId: trip.carrierId,
//             title: 'مسافر أكمّل بيانات الحجز ✅',
//             body: `${passengers[0]?.name || 'مسافر'} دفع العربون — ${passengers.length} مقعد`,
//             data: { type: 'passenger_deposit_paid', bookingId: tokenData.bookingId },
//           });
//         }

//         try {
//           const groupChatRef = doc(firestore, 'chats', trip.id);
//           await setDoc(groupChatRef, { participants: arrayUnion(user.uid) }, { merge: true });
//         } catch (e) {
//           console.warn('[GroupChat] Could not join:', e);
//         }

//       } else {
//         // ══════════════════════════════════════════════════════════════════
//         // المسار العادي: مسافر مباشر بدون وكيل → booking جديد
//         // ══════════════════════════════════════════════════════════════════
//         const bookingRef = doc(collection(firestore, 'bookings'));

//         // [FIX]: نستخدم tokenData.carrierId لأن trip.carrierId اتمسح من handleAcceptOffer
//         // أو ممكن يكون في pendingCarrierId (من العرض)
//         const effectiveCarrierId = tokenData.carrierId || (trip as any).pendingCarrierId || trip.carrierId || null;
//         const notificationRef = effectiveCarrierId
//           ? doc(collection(doc(firestore, 'users', effectiveCarrierId), 'notifications'))
//           : null;

//         // ✅ التفرقة بين رحلة مجدولة وطلب خاص
//         // رحلة مجدولة = حالتها Planned أو Ongoing أو الناقل هو من أنشأها
//         const isScheduledTrip = trip.status === 'Planned' || trip.status === 'Ongoing' || (trip.userId === (trip.carrierId || effectiveCarrierId));

//         // دايمًا Pending-Carrier-Confirmation — الناقل يقرر: يوافق فوراً لو عنده رحلة، وإلا ينشئ رحلة جديدة
//         const newBookingStatus = 'Pending-Carrier-Confirmation';

//         batch.set(bookingRef, {
//           id: bookingRef.id,
//           tripId: trip.id,
//           carrierTripId: isScheduledTrip ? trip.id : (tokenData.carrierTripId || null),
//           userId: user.uid,
//           carrierId: trip.carrierId || tokenData.carrierId,
//           seats: passengers.length,
//           passengersDetails: passengers,
//           status: newBookingStatus,
//           totalPrice: (tokenData.price || trip.price || 0) * passengers.length,
//           currency: tokenData.currency || trip.currency || 'JOD',
//           depositPercentage: trip.depositPercentage ?? 0,
//           verifiedEmail: tokenData.email || null,
//           bookedByAgent: false,
//           requestOrigin: trip.origin,
//           requestDestination: trip.destination,
//           requestDepartureDate: trip.departureDate,
//           requestPassengers: passengers.length,
//           createdAt: serverTimestamp(),
//           updatedAt: serverTimestamp(),
//         });

//         batch.update(tokenRef, { status: 'used', usedAt: serverTimestamp() });

//         // ✅ [FIX]: التحديث حسب نوع الرحلة
//         if (isScheduledTrip) {
//           // 1️⃣ إذا كانت رحلة مجدولة، لا نغير حالتها أبداً (تظل Planned)
//           // نضيف فقط معرف الحجز إليها لكي تظهر للناقل
//           const tripUpdateRef = doc(firestore, 'trips', trip.id);
//           batch.update(tripUpdateRef, {
//             bookingIds: arrayUnion(bookingRef.id),
//             updatedAt: serverTimestamp(),
//           });
//         } else {
//           // 2️⃣ إذا كان طلب مسافر (طلب خاص)، نحدّث حالته لـ Pending-Carrier-Confirmation
//           // [FIX]: نمسح carrierId و pendingCarrierId من رحلة المسافر — مش رحلة الناقل
//           // carrierId هيرجع يتحط لما الناقل ينشئ رحلته فعلاً (في handleTripCreated)
//           const tripUpdateRef = doc(firestore, 'trips', trip.id);
//           batch.update(tripUpdateRef, {
//             status: 'Pending-Carrier-Confirmation',
//             pendingBookingId: bookingRef.id,
//             carrierId: deleteField(),
//             pendingCarrierId: deleteField(),
//             updatedAt: serverTimestamp(),
//           });

//           // لو الناقل كان رابط عرضه برحلة مجدولة عنده مسبقاً، نضيف الحجز ليها
//           if (tokenData.carrierTripId) {
//             const carrierTripRef = doc(firestore, 'trips', tokenData.carrierTripId);
//             batch.update(carrierTripRef, {
//               bookingIds: arrayUnion(bookingRef.id),
//               updatedAt: serverTimestamp(),
//             });
//           }
//         }

//         const userRef = doc(firestore, 'users', user.uid);
//         batch.set(userRef, {
//           activeBookingId: bookingRef.id,
//           // activeIntentId: null,
//           activeIntentId: deleteField(),
//           updatedAt: serverTimestamp(),
//         }, { merge: true });

//         // إشعارات مخصصة حسب نوع الرحلة
//         if (effectiveCarrierId && notificationRef) {
//           batch.set(notificationRef, {
//             userId: effectiveCarrierId,
//             title: isScheduledTrip ? 'حجز جديد في رحلتك المجدولة! 🎫' : 'المسافر وافق على عرضك — في انتظار قبولك 🎉',
//             message: isScheduledTrip
//               ? `المسافر "${passengers[0]?.name || ''}" حجز ${passengers.length} مقعد في رحلتك المجدولة — يرجى تأكيد الحجز.`
//               : `المسافر "${passengers[0]?.name || ''}" وافق على عرضك — اضغط لقبول الحجز.`,
//             type: 'new_booking_request',
//             bookingId: bookingRef.id,
//             isRead: false,
//             link: `/${locale}/carrier/bookings`,
//             createdAt: serverTimestamp(),
//           });
//         }

//         await batch.commit();

//         if (effectiveCarrierId) {
//           await sendPush({
//             userId: effectiveCarrierId,
//             title: isScheduledTrip ? 'حجز جديد في رحلتك المجدولة! 🎫' : 'المسافر وافق على عرضك! 🎉',
//             body: isScheduledTrip
//               ? `المسافر "${passengers[0]?.name || 'مسافر'}" بانتظار تأكيد حجز ${passengers.length} مقعد`
//               : `${passengers[0]?.name || 'مسافر'} وافق — افتح التطبيق لقبول الحجز`,
//             data: { type: 'new_booking_request' },
//           });
//         }

//         try {
//           const groupChatRef = doc(firestore, 'chats', trip.id);
//           await setDoc(groupChatRef, { participants: arrayUnion(user.uid) }, { merge: true });
//         } catch (e) {
//           console.warn('[GroupChat] Could not join:', e);
//         }
//       }

//       setIsDialogOpen(false);
//       setStatus('success');

//     } catch (err) {
//       console.error('[ConfirmBooking Error]', err);
//       setStatus('error');
//       setErrorCode('OPERATION_FAILED');
//       throw err;
//     }
//   };

//   return (
//     <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-background" dir="rtl">
//       {status === 'loading' && (
//         <div className="text-center space-y-4">
//           <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
//           <p className="text-muted-foreground">جاري فحص الختم الرقمي...</p>
//         </div>
//       )}

//       {(status === 'ready' || status === 'confirming') && trip && (
//         <div className="text-center space-y-4">
//           <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
//           <p className="text-muted-foreground">جاري استرجاع بيانات الرحلة...</p>
//         </div>
//       )}

//       {status === 'success' && (
//         <div className="text-center space-y-6 max-w-md animate-in zoom-in duration-500">
//           <CheckCircle2 className="h-20 w-20 text-green-500 mx-auto" />
//           <h1 className="text-2xl font-bold text-white">{t('accptReq')} 🎉</h1>
//           <Button className="w-full" onClick={() => router.push(`/${locale}/history`)}>
//             {t('gotoReq')}
//           </Button>
//         </div>
//       )}

//       {status === 'error' && (
//         <div className="text-center space-y-6 max-w-md animate-in shake duration-500">
//           <XCircle className="h-20 w-20 text-red-500 mx-auto" />
//           <h1 className="text-2xl font-bold">تنبيه سيادي</h1>
//           <p className="text-muted-foreground">{tError(errorCode)}</p>
//           <Button className="w-full" onClick={() => router.push(`/${locale}/dashboard`)}>
//             العودة للرئيسية
//           </Button>
//         </div>
//       )}

//       {trip && isDialogOpen && (
//         <BookingDialog
//           isOpen={isDialogOpen}
//           onOpenChange={(open) => {
//             setIsDialogOpen(open);
//             if (!open && status === 'ready') router.push(`/${locale}/dashboard`);
//           }}
//           trip={trip}
//           seatCount={tokenData?.seatCount || 1}
//           onSubmit={handleConfirmBooking}
//           isProcessing={status === 'confirming'}
//           // ✅ [FIX]: تمرير أنواع الركاب من الطلب الأصلي للتعبئة التلقائية
//           passengerTypes={
//             // ✅ [FIX]: نمرر أنواع الركاب من الطلب الأصلي — child→minor لضمان التوافق مع RadioGroup
//             (trip.passengersDetails && trip.passengersDetails.length > 0)
//               ? trip.passengersDetails.map(p => {
//                 const t = p.type as string;
//                 return (t === 'child' ? 'minor' : t) as 'adult' | 'minor' | 'infant';
//               })
//               : undefined
//           }
//         />
//       )}
//     </div>
//   );
// }

'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useFirestore, useUser } from '@/firebase';
import { doc, getDoc, collection, serverTimestamp, writeBatch, arrayUnion, increment, setDoc, deleteField } from 'firebase/firestore';
import { Loader2, CheckCircle2, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { BookingDialog } from '@/components/booking-dialog';
import type { Trip, PassengerDetails } from '@/lib/data';
import { useLocale, useTranslations } from 'next-intl';
import { sendPush } from "@/lib/send-push";

/**
 * @file src/app/[locale]/confirm-booking/page.tsx
 * @description THE STERILIZED BOOKING CONFIRMATION (REINFORCED - SC-806 V6.1)
 * [FIX]: تم الفصل الذكي بين حجز "الرحلات المجدولة" و "الطلبات الخاصة" لمنع اختفاء الرحلات
 */

type Status = 'loading' | 'ready' | 'confirming' | 'success' | 'error' | 'expired';

export default function ConfirmBookingPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center min-h-screen"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>}>
      <ConfirmBookingContent />
    </Suspense>
  );
}

function ConfirmBookingContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const firestore = useFirestore();
  const { user } = useUser();
  const locale = useLocale();
  const tError = useTranslations('errorDictionary');
  const t = useTranslations('ConfirmBooking');
  const token = searchParams.get('token');

  const [status, setStatus] = useState<Status>('loading');
  const [tokenData, setTokenData] = useState<any>(null);
  const [trip, setTrip] = useState<Trip | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [errorCode, setErrorCode] = useState('DEFAULT');

  useEffect(() => {
    if (!token || !firestore) return;

    const verifyToken = async () => {
      try {
        const tokenRef = doc(firestore, 'booking_tokens', token);
        const tokenSnap = await getDoc(tokenRef);

        if (!tokenSnap.exists()) {
          setStatus('error');
          setErrorCode('TOKEN_INVALID');
          return;
        }

        const data = tokenSnap.data();

        if (data.status === 'used') {
          setStatus('error');
          setErrorCode('TOKEN_USED');
          return;
        }

        const expiresAt = data.expiresAt?.toDate?.() || new Date(data.expiresAt);
        if (new Date() > expiresAt) {
          setStatus('error');
          setErrorCode('TOKEN_EXPIRED');
          return;
        }

        const tripRef = doc(firestore, 'trips', data.tripId);
        const tripSnap = await getDoc(tripRef);

        if (!tripSnap.exists()) {
          setStatus('error');
          setErrorCode('TRIP_NOT_FOUND');
          return;
        }

        setTokenData(data);
        setTrip({ id: tripSnap.id, ...tripSnap.data() } as Trip);
        setStatus('ready');
        setIsDialogOpen(true);
      } catch (err) {
        console.error('[VerifyToken Error]', err);
        setStatus('error');
        setErrorCode('VERIFICATION_FAILED');
      }
    };

    verifyToken();
  }, [token, firestore]);

  const handleConfirmBooking = async (passengers: PassengerDetails[]) => {
    if (!firestore || !tokenData || !trip || !token) throw new Error('MISSING_DATA');
    if (!user?.uid) throw new Error('AUTH_REQUIRED');

    setStatus('confirming');

    try {
      const batch = writeBatch(firestore);
      const tokenRef = doc(firestore, 'booking_tokens', token);

      if (tokenData.bookingId) {
        // ══════════════════════════════════════════════════════════════════
        // المسار الجاي من وكيل
        // ══════════════════════════════════════════════════════════════════
        const existingBookingRef = doc(firestore, 'bookings', tokenData.bookingId);

        batch.update(existingBookingRef, {
          userId: user.uid,
          passengersDetails: passengers,
          seats: passengers.length,
          depositPaid: true,
          depositPercentage: trip.depositPercentage ?? 0,
          verifiedEmail: tokenData.email || null,
          status: 'Pending-Carrier-Confirmation',
          updatedAt: serverTimestamp(),
        });

        batch.update(tokenRef, { status: 'used', usedAt: serverTimestamp() });

        if (tokenData.carrierTripId) {
          const carrierTripRef = doc(firestore, 'trips', tokenData.carrierTripId);
          batch.update(carrierTripRef, {
            bookingIds: arrayUnion(tokenData.bookingId),
            updatedAt: serverTimestamp(),
          });
        }

        const userRef = doc(firestore, 'users', user.uid);
        batch.set(userRef, {
          activeBookingId: tokenData.bookingId,
          // activeIntentId: null,
          activeIntentId: deleteField(),

          updatedAt: serverTimestamp(),
        }, { merge: true });

        if (trip.carrierId) {
          const notifRef = doc(collection(doc(firestore, 'users', trip.carrierId), 'notifications'));
          batch.set(notifRef, {
            userId: trip.carrierId,
            title: 'مسافر أكمّل بيانات الحجز ✅',
            message: `المسافر "${passengers[0]?.name || ''}" أكمل بياناته ودفع العربون — ${passengers.length} مقعد`,
            type: 'passenger_deposit_paid',
            bookingId: tokenData.bookingId,
            isRead: false,
            link: `/${locale}/carrier/bookings`,
            createdAt: serverTimestamp(),
          });
        }

        await batch.commit();

        if (trip.carrierId) {
          await sendPush({
            userId: trip.carrierId,
            title: 'مسافر أكمّل بيانات الحجز ✅',
            body: `${passengers[0]?.name || 'مسافر'} دفع العربون — ${passengers.length} مقعد`,
            data: { type: 'passenger_deposit_paid', bookingId: tokenData.bookingId },
          });
        }

        try {
          const groupChatRef = doc(firestore, 'chats', trip.id);
          await setDoc(groupChatRef, { participants: arrayUnion(user.uid) }, { merge: true });
        } catch (e) {
          console.warn('[GroupChat] Could not join:', e);
        }

      } else {
        // ══════════════════════════════════════════════════════════════════
        // المسار العادي: مسافر مباشر بدون وكيل → booking جديد
        // ══════════════════════════════════════════════════════════════════
        const bookingRef = doc(collection(firestore, 'bookings'));

        const effectiveCarrierId = tokenData.carrierId || (trip as any).pendingCarrierId || trip.carrierId || null;
        const notificationRef = effectiveCarrierId
          ? doc(collection(doc(firestore, 'users', effectiveCarrierId), 'notifications'))
          : null;

        // ✅ [FIX]: carrierTripId من الـ token (اللي يجي من رحلة الناقل الحقيقية)
        // لو مفيش carrierTripId في الـ token → رحلة المسافر هي الأصل (طلب بدون ناقل بعد)
        const effectiveCarrierTripId = tokenData.carrierTripId || null;
        const isScheduledTrip = !!effectiveCarrierTripId ||
          trip.status === 'Planned' || trip.status === 'Ongoing';

        const newBookingStatus = 'Pending-Carrier-Confirmation';

        batch.set(bookingRef, {
          id: bookingRef.id,
          tripId: trip.id,                                           // رحلة المسافر (الطلب الأصلي)
          carrierTripId: effectiveCarrierTripId,                     // ✅ [FIX]: رحلة الناقل الحقيقية
          userId: user.uid,
          carrierId: effectiveCarrierId,
          seats: passengers.length,
          passengersDetails: passengers,
          status: newBookingStatus,
          totalPrice: (tokenData.price || trip.price || 0) * passengers.length,
          currency: tokenData.currency || trip.currency || 'JOD',
          depositPercentage: trip.depositPercentage ?? 0,
          verifiedEmail: tokenData.email || null,
          bookedByAgent: false,
          requestOrigin: trip.origin,
          requestDestination: trip.destination,
          requestDepartureDate: trip.departureDate,
          requestPassengers: passengers.length,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        batch.update(tokenRef, { status: 'used', usedAt: serverTimestamp() });

        // ✅ [FIX]: دايماً حدّث رحلة المسافر بـ pendingBookingId
        batch.update(doc(firestore, 'trips', trip.id), {
          status: 'Pending-Carrier-Confirmation',
          pendingBookingId: bookingRef.id,
          carrierId: deleteField(),
          pendingCarrierId: deleteField(),
          updatedAt: serverTimestamp(),
        });

        // ✅ [FIX]: لو في carrierTripId → أضف الـ booking لرحلة الناقل الحقيقية وخصم المقاعد
        if (effectiveCarrierTripId) {
          batch.update(doc(firestore, 'trips', effectiveCarrierTripId), {
            bookingIds: arrayUnion(bookingRef.id),   // ✅ يظهر عند الناقل
            updatedAt: serverTimestamp(),
          });
        }

        const userRef = doc(firestore, 'users', user.uid);
        batch.set(userRef, {
          activeBookingId: bookingRef.id,
          // activeIntentId: null,
          activeIntentId: deleteField(),
          updatedAt: serverTimestamp(),
        }, { merge: true });

        // إشعارات مخصصة حسب نوع الرحلة
        if (effectiveCarrierId && notificationRef) {
          batch.set(notificationRef, {
            userId: effectiveCarrierId,
            title: isScheduledTrip ? 'حجز جديد في رحلتك المجدولة! 🎫' : 'المسافر وافق على عرضك — في انتظار قبولك 🎉',
            message: isScheduledTrip
              ? `المسافر "${passengers[0]?.name || ''}" حجز ${passengers.length} مقعد في رحلتك المجدولة — يرجى تأكيد الحجز.`
              : `المسافر "${passengers[0]?.name || ''}" وافق على عرضك — اضغط لقبول الحجز.`,
            type: 'new_booking_request',
            bookingId: bookingRef.id,
            isRead: false,
            link: `/${locale}/carrier/bookings`,
            createdAt: serverTimestamp(),
          });
        }

        await batch.commit();

        if (effectiveCarrierId) {
          await sendPush({
            userId: effectiveCarrierId,
            title: isScheduledTrip ? 'حجز جديد في رحلتك المجدولة! 🎫' : 'المسافر وافق على عرضك! 🎉',
            body: isScheduledTrip
              ? `المسافر "${passengers[0]?.name || 'مسافر'}" بانتظار تأكيد حجز ${passengers.length} مقعد`
              : `${passengers[0]?.name || 'مسافر'} وافق — افتح التطبيق لقبول الحجز`,
            data: { type: 'new_booking_request' },
          });
        }

        try {
          const groupChatRef = doc(firestore, 'chats', trip.id);
          await setDoc(groupChatRef, { participants: arrayUnion(user.uid) }, { merge: true });
        } catch (e) {
          console.warn('[GroupChat] Could not join:', e);
        }
      }

      setIsDialogOpen(false);
      setStatus('success');

    } catch (err) {
      console.error('[ConfirmBooking Error]', err);
      setStatus('error');
      setErrorCode('OPERATION_FAILED');
      throw err;
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-background" dir="rtl">
      {status === 'loading' && (
        <div className="text-center space-y-4">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
          <p className="text-muted-foreground">جاري فحص الختم الرقمي...</p>
        </div>
      )}

      {(status === 'ready' || status === 'confirming') && trip && (
        <div className="text-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
          <p className="text-muted-foreground">جاري استرجاع بيانات الرحلة...</p>
        </div>
      )}

      {status === 'success' && (
        <div className="text-center space-y-6 max-w-md animate-in zoom-in duration-500">
          <CheckCircle2 className="h-20 w-20 text-green-500 mx-auto" />
          <h1 className="text-2xl font-bold text-white">{t('accptReq')} 🎉</h1>
          <Button className="w-full" onClick={() => router.push(`/${locale}/history`)}>
            {t('gotoReq')}
          </Button>
        </div>
      )}

      {status === 'error' && (
        <div className="text-center space-y-6 max-w-md animate-in shake duration-500">
          <XCircle className="h-20 w-20 text-red-500 mx-auto" />
          <h1 className="text-2xl font-bold">تنبيه سيادي</h1>
          <p className="text-muted-foreground">{tError(errorCode)}</p>
          <Button className="w-full" onClick={() => router.push(`/${locale}/dashboard`)}>
            العودة للرئيسية
          </Button>
        </div>
      )}

      {trip && isDialogOpen && (
        <BookingDialog
          isOpen={isDialogOpen}
          onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open && status === 'ready') router.push(`/${locale}/dashboard`);
          }}
          trip={trip}
          seatCount={tokenData?.seatCount || 1}
          onSubmit={handleConfirmBooking}
          isProcessing={status === 'confirming'}
          // ✅ [FIX]: تمرير أنواع الركاب من الطلب الأصلي للتعبئة التلقائية
          passengerTypes={
            // ✅ [FIX]: نمرر أنواع الركاب من الطلب الأصلي — child→minor لضمان التوافق مع RadioGroup
            (trip.passengersDetails && trip.passengersDetails.length > 0)
              ? trip.passengersDetails.map(p => {
                const t = p.type as string;
                return (t === 'child' ? 'minor' : t) as 'adult' | 'minor' | 'infant';
              })
              : undefined
          }
        />
      )}
    </div>
  );
}